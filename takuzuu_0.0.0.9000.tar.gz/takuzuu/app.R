library(shiny)
library(bslib)
library(shinyjs)
library(takuzuu)

ui <- fluidPage(
  useShinyjs(),
  theme = bs_theme(bootswatch = "flatly"),
  titlePanel("🧠 Jeu Takuzu"),

  card(
    full_screen = TRUE,
    height = "auto",
    card_header("🎮 Plateau de jeu interactif"),
    layout_sidebar(
      fillable = TRUE,
      sidebar = sidebar(
        title = "Actions",
        selectInput("grid_size", "Taille de la grille", choices = c("4x4" = 4, "6x6" = 6, "8x8" = 8), selected = 6),
        actionButton("regen", "🔄 Nouvelle Grille", class = "btn-primary"),
        actionButton("validate", "✅ Valider la Grille", class = "btn-success"),
        textOutput("status")
      ),
      uiOutput("grid")
    )
  )
)

server <- function(input, output, session) {
  grid <- reactiveVal(NULL)
  fixed_cells <- reactiveVal(NULL)
  solution <- reactiveVal(NULL)
  status_message <- reactiveVal("Sélectionnez une taille de grille pour commencer.")

  generate_new_grid <- function() {
    taille <- as.numeric(input$grid_size)
    jeu <- generer_takuzu_jouable(taille, proportion_visible = 0.35)
    grid(jeu$grille_visible)
    solution(jeu$solution)
    fixed_cells(!is.na(jeu$grille_visible))
    status_message("Nouvelle grille générée.")
  }

  observeEvent(input$regen, generate_new_grid)
  observeEvent(input$grid_size, generate_new_grid)

  output$grid <- renderUI({
    g <- grid()
    fixed <- fixed_cells()
    if (is.null(g) || is.null(fixed)) return(h4("⬅ Choisissez une taille de grille pour commencer"))

    n <- nrow(g)
    m <- ncol(g)
    grid_html <- tagList()

    for (i in 1:n) {
      row <- tagList()
      for (j in 1:m) {
        cell_id <- paste0("cell_", i, "_", j)
        value <- g[i, j]
        label <- ifelse(is.na(value), "", as.character(value))

        row[[j]] <- actionButton(
          inputId = cell_id,
          label = label,
          style = "width: 50px; height: 50px; font-size: 18px; margin: 2px;",
          disabled = fixed[i, j]
        )
      }
      grid_html[[i]] <- div(style = "display: flex;", row)
    }

    tagList(grid_html)
  })

  observe({
    g <- grid()
    fixed <- fixed_cells()
    if (is.null(g) || is.null(fixed)) return()

    n <- nrow(g)
    m <- ncol(g)

    for (i in 1:n) {
      for (j in 1:m) {
        if (fixed[i, j]) next

        local({
          row <- i
          col <- j
          cell_id <- paste0("cell_", row, "_", col)

          observeEvent(input[[cell_id]], {
            current <- isolate(grid())
            val <- current[row, col]
            new_val <- if (is.na(val)) 0 else if (val == 0) 1 else NA
            current[row, col] <- new_val
            grid(current)
          }, ignoreInit = TRUE)
        })
      }
    }
  })

  observeEvent(input$validate, {
    g <- grid()
    if (is.null(g)) {
      status_message("❗ Veuillez d'abord générer une grille.")
      return()
    }

    msg <- if (!check_no_triplets(g)) {
      "❌ Il y a des triplets (000 ou 111) dans la grille."
    } else if (!check_balance(g)) {
      "❌ Répartition des 0 et 1 incorrecte."
    } else if (!check_unique_rows_cols(g)) {
      "❌ Lignes ou colonnes identiques."
    } else if (!check_no_na(g)) {
      "⚠️ Il reste des cases vides."
    } else {
      "✅ Bravo, grille correcte ! 🎉"
    }

    status_message(msg)
  })

  output$status <- renderText({ status_message() })
}

shinyApp(ui, server)
